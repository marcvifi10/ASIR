<?php
$myServer = �TEST-SQL\SQLEXPRESS"; // Nom del servidor i instancia SQL
$uid = "sa";
$pass = �practica";
$myDB = "test";
$serverName = $myServer;
$connectionInfo = array ("UID"=> $uid, "PWD" => $pass, "Database" => $myDB);
echo "Connectant ...";
$conn = sqlsrv_connect($serverName,$connectionInfo);
if ($conn == false){
echo "Connection not correct";
die (print_r(sqlsrv_errors(),true));
}
else
{
echo �Connectat�;
}
?>