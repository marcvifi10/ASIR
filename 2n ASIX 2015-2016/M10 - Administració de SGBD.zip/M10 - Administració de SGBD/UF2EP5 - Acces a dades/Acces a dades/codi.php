<html>
<head>
<title>Base de dades dels alumnes matriculats</title>
<h1 align="center">BASE DE DADES DELS ALUMNES MATRICULATS </h1>
</head>
<body>
<?php 
$myServer = "MARCVIFI\MARCVIFI"
$myUser = "sa"
$myPass = "123456789"
$myDB = "MATRICULATS"

 //connexi� a la base de dades
$dbconnexio = mysql_connect($myServer, $myUser, $myPass) 
Or die("No es pot conectar!!!!");

//seleccionar la base de dades
$selected = mysql_select_db($myDB, $dbconnexio)
Or die ("No s�ha pogut obrir la base de dades $myDB");

//declarar SQL statement 
$query = "SELECT * ";
$query .= "FROM Alumnes";

$query = "SELECT * ";
$query .= "FROM assignatures";
$query = SELECT a.id_assignatura, c.DNI_ALUMNE
$query .= FROM assignatures a, alumnes c

//executar SQL query i tornar 
$result = mysql_query ($query);
$numRows = mysql_num_rows($result);
Echo "<h1>" . $numRows . " Row" . ($numRows == 1 � "" ; "s") . " Torna </h1>";

//Resultats
While ($row = mysql_fetch_array ($result))
{
Echo "<li>" . $row[""]
}
//mostrar els resultats
While ($row = mysql_fetch_array($result))
{
Echo "<li>" . $row["DNI_ALUMNE"] . $row["id_assignatura"] . "</li>";
}
//Tanquem la connexi�
Mssql_close ($dbconnexio);
?>
</body>
</html>
