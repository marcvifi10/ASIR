<html> 
<head> 
<title>Country Data</title> 
<h1 color="blue" align="center">Country Data</h1> 
</head> 
<body> 
<form method="GET" action="country_data.php">  
<input type="text" name="inp_get"><br>  
<input type="submit">  
</form>  
<?php  
$link = mysql_connect();  
if (!$conneccio)   
{  
die('No es troba connectat a la base de dades: '.mysql_error() );  
}  
$db_selected = mysql_select_db ('bdd_world', $link);  
if (!$db_selected)  
{  
die ('No es pot emprar la nostra base de dades bdd_World : '.mysql_error());  
}  
$input = $_GET[""];  
$query = "Select name From country".  
"WHERE name LIKE '%$input%'+ ";  
$result = mysql_query($query);  
$num_rows = mysql_num_rows($result);  
$num_fields = mysql_num_fields($result);  
while ($row = mysql_fetch_row($result)) 
{  
for ($i = 0; $i <= $num_fields; $i++)  
{  
echo($row[$i].' ');   
}  
echo('<br>');  
}  
mysql_free_result ($result);  
mysql_close($connecio);  
?>   
</body> 
</html>