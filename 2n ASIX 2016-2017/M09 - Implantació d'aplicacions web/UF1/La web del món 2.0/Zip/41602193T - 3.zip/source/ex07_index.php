<html> 
	<head>
		<title>EMAIL</title>
		<h1>E-mail</h1>
	</head> 
	<body> 
		<form action="validar.php" method="post"> 
		<?php 
			$Correu=$_COOKIE["Correu"]; 
			$Contrasenya=$_COOKIE["Passwd"]; 
			$Contrasenya=$_COOKIE["Passwd2"]; 
			echo "<p>Email </br><input type='text' name='correu' value = $Correu/></br></p>"; 
			echo "<p>Contrasenya</br><input type='password' name='password' value =$Contrasenya /></br></p>"; 
			echo "<p>Contrasenya</br><input type='password' name='password2' value = $Contrasenya /></p>"; 
		?> 
		<p><input type="submit" value="Comprova" name="submit"/></p>
		</form> 
	</body> 
</html>
