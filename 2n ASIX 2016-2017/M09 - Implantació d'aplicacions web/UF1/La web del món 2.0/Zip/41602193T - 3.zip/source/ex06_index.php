<html> 

	<head>

		<title>E-mail</title>
	
		<h1>Email</h1>

	</head> 

	<body> 

		<form action="validar.php" method="post"> 

			<p>E-mail</br><input type="text" name="correu" /></br></p> 

			<p>Contrasenya</br><input type="password" name="Contrasenya"/></br></p> 

			<p>Contrasenya2</br><input type="password" name="Contrasenya2"/></p> 

			<p><input type="submit" value="Comprova" name="submit"</p> 

		</form> 

	</body> 

</html> 

