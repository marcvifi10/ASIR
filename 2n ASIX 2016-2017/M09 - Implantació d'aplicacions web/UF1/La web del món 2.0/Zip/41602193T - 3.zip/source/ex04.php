<html>
	<head>
		<title>1000� nombre primer</title>
		<h1>1000� nombre primer</h1>
	</head>
	<body>
		<?php
			$Divisor;
			$Comptador=0;
			$Num=2;
			$Max;
			while ($Comptador<1000) {
				$Divisor=2;
				while ($Num%$Divisor!=0) {
					$Divisor++;
				}
				if ($Divisor==$Num) {
					$Max=$Num;
					$Comptador++;
				}
				$Num++;
			}
			echo "El 1000� nombre primer �s el $Max" 		
		?>
	</body>
<html>
