<html>
	<head>
		<title>Taules de multiplicar dels nombres de l�1 al 10</title>
		<h1>Taules de multiplicar dels nombres de l�1 al 10</h1>
	</head>
	<body>
		<?php
			for ($a=1;$a<=10;$a++) {
				echo "<b>"."Taula de multiplicar del nombre ".$i"</b>"."<br><br>";
				for ($b=1;$b<=10;$b++) {
					$Resultat=$a*$b;
					echo "".$a." * ".$b." = ".$Resultat."<br>";
				}
			echo "<br><br>";
			}
		?>
	</body>
</html>
