<html>
	<head>
		<title>EMAIL</title>
		<h1>EMAIL</h1>
	</head>
	<body> 
		<?php 
			$Correu=$_POST['correu']; 
			$Contrasenya=$_POST['password']; 
			$Contrasenya2=$_POST['password2']; 
			$a=strstr($Correu, '@', true); 
			$p=strstr($Correu, '.', true); 
			if (!$a) $i = 1; 
				else if (!$p) $i = 2; 
				else if ( 5 > strlen($Contrasenya) or 5 > strlen($Contrasenya2)) $i=3; 
				else if ($Contrasenya != $Contrasenya2) $i=4; 
				else $i=5; 
			switch ($i){ 
				case 1: 
					echo "El correu $Correu no es correcte (fa falta @)."; 
					break; 
				case 2: 
					echo "El correu $Correu no es correcte (fa falta .)."; 
					break; 
				case 3: 
					echo ""La contrasenya ha de ser de com a m�nim cinc car�cters."; 
					break;
				case 4: 
					echo "Les contrasenyes s�n diferents."; 
					break;
				case 5: 
					echo "El correu $Correu �s correcte."; 
					setcookie("Correu","$Correu", time() + 259200); 
					setcookie("Contrasenya","$Contrasenya", time() + 259200); 
					setcookie("Contrasenya2","$Contrasenya2", time() + 259200); 
					break; 
				} 		
		?> 
	</br><h1><a href="index.php"> Tornar</a> </h1> 
	</body> 
</html>
