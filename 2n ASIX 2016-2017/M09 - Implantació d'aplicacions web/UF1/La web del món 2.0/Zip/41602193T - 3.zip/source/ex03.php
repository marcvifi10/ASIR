<html>
	<head>
		<title>Suma dels valors parells</title>
		<h1>Suma dels valors parells</h1>
	</head>
	<body>
		<?php
			$Anterior=1;
			$Actual=1;
			$Resultat=0;
			do {
				if ($Actual%2==0) $Resultat+=$Actual;
				$Temporal=$Anterior;
				$Anterior=$Actual;
				$Actual=$Temporal+$Anterior;
			} while ($Actual<4000000);
			echo "Resultat: ".$Resultat;
		?>
	</body>
</html>
