<html> 
	<head>
		<title>Taules de multiplicar</title>
		<h1>Taules de multiplicar</h1>
	</head> 
	<body> 
		<?php 
			$Escriure=""; 
			$Fitxer=fopen('taules.txt','w'); 
			for($a=1;$a<=10;$a++) { 
				$Escriure= "Taula del ".$a; 
				fwrite($Fitxer,$Escriure); 
				for($num=1;$num<=10;$num++) { 
					$Escriure=$a." x ".$num."=".($a*$num).chr(10); 
					fwrite($Fitxer,$Escriure); 
				} 
			} 
			echo "L�arxiu anomenat taules.txt ha estat creat"; 
			?> 
	</body> 
</html>
