<html>
	<head>
		<title>DNI</title>
		<h1>DNI</h1>
	</head>
	<body>
		<form method="post" action="
		<?php echo $PHP_SELF;?>"> 
			<table border="0"> 
				<tr> 
					<td> DNI: </td><td> <input type="text" name="dni" /></td> 
					<td> <input type="submit" value="Comprova" name="submit"/> 
				</tr> 
			</table> 
		<?php 
			function DNI_valid ($cadena) { 
			if (strlen($cadena) != 9) return false; 
			$ValorsLletra = array( 
0 => 'T', 1 => 'R', 2 => 'W', 3 => 'A', 4 => 'G', 5 => 'M', 
6 => 'Y', 7 => 'F', 8 => 'P', 9 => 'D', 10 => 'X', 11 => 'B', 
12 => 'N', 13 => 'J', 14 => 'Z', 15 => 'S', 16 => 'Q', 17 => 'V', 
18 => 'H', 19 => 'L', 20 => 'C', 21 => 'K',22 => 'E' 
			); 
			if (preg_match('/^[0-9]{8}[A-Z]$/i', $cadena)) { 
				if (strtoupper($cadena[strlen($cadena) - 1]) != 	
					$ValorsLletra[((int) substr($cadena, 0, strlen($cadena) - 1)) % 23]) 
				return false; 
			return true; 
			} else if (preg_match('/^[XYZ][0-9]{7}[A-Z]$/i', $cadena)) { 
				if (strtoupper($cadena[strlen($cadena) - 1]) != 
					$ValorsLletra[((int) substr($cadena, 1, strlen($cadena) - 2)) % 23]) 
				return false;
			return true; 
			} 
			return false; 
			} 
			if(isset($_POST['submit'])) { 
				$DNITest = $_REQUEST['dni']; 
				if (DNI_valid($DNITest)) echo "Correcte"; 
				else echo "Incorrecte"; 
			} 
			?>
		</form> 
	</body>
</html>
