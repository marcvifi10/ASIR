<html>
	<head>
		<title>Taula 15x15 amb caselles numerades</title>
		<h1>Taula 15x15 amb caselles numerades</h1>
	</head>
	<body>
		<table border="1">
			<?php
				$Comptador=1;
				for ($a=1;$a<=15;$a++) {
					echo "<tr>";
					for ($b=1;$b<=15;$b++) {
						$Celes=$Comptador%4;
						switch ($Celes) {
							case 0: 
								$Color="blue"; 
							break; 
							case 1: 
								$Color="red"; 
							break;
							case 2: 
								$Color="green"; 
							break;
							case 3: 
								$Color="yellow"; 
							break;
						}
						echo "<td bgcolor='".$Color."'>".$Comptador++."</td>";
					}
					echo "</tr>";
				}
			?>
		</table>
	</body>
</html>  
