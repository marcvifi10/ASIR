<html>
        <head>
                <title>top_cities.php</title>
        </head>
        <body bgcolor="#A9CCE3">
                <?php
//Un cop hem obert la �part� php, el primer que tenim que fer es establir la connexi� amb l�usuari userbddworld, de la base de dades bdd_world.
                        $connexio = mysql_connect('localhost', 'userbddworld', 'asixmp09aea1031617');
                       if (!$connexio) {
                                die('No es pot connectar a la seva base de dades: ' .mysql_error());
                        }
//Tot seguit, fem lo mateix que el pas anterior, per� en aquest cas es si s�ha connectat amb la base de dades bdd_world, i en cas negatiu mostraria un missatge d�error.
                       if (!mysql_select_db('bdd_world')){
                                die('No es pot connectar amb la base de dades : ' .mysql_error());
                        }
//Creem una variable anomenada $consulta, on hi guardem el resultat d�una consulta SQL gr�cies a mysql_query.
$resultat = mysql_query("SELECT City.Name, City.Population, Country.Name, Country.Continent FROM City City, Country Country WHERE City.CountryCode = Country.Code ORDER BY City.Population DESC");
//Per poder seleccionar nom�s 25 pa�sos, el que tenim que fer es crear una variable anomenada nCiutats, per poder controlar el nombre que hi entrem. 
                        $nCiutats = 0;
//Mitjan�ant un while, mostrarem nom�s els 25 pa�sos, amb m�s poblaci�.
//Els resultats de les consultes s�emmagatzemen a la variable row.
                        while ($row = mysql_fetch_array($resultat) and $nCiutats < 25)
                        {
//Mostrarem mitjan�ant un echo els resultats de les consultes.
                                echo "<h1>$row[0]</h1>";
                                echo "<a href = city_data.php?ciutat=$row[0]><FONT FACE='Courier, Lucida Console, Consolas'>$row[0](Console, Consolas'>$row[1](HABITANTS)</FONT></a>";
                                echo "<h2>HABITANTS</h2>";
                                echo "<h3>$row[1]</h3>";
                                echo "<br></br>";
                                echo "<h2>PAIS</h2>";
                                echo "<h3>$row[2]</h3>";
                                echo "<br></br>";
                                echo "<h2>CONTINENT</h2>";
                                echo "<h3>$row[3]</h3>";
                                echo "<br></br>";
//Gr�cies a la variable nCiutats, anir� mostrant les dades dels pa�sos fins que nCiutats sigui igual a 25, que es quan parar�.
                                $nCiutats++;
                        }
//Alliberem el resultat i tanquem la connexi�.
                        mysql_free_result($resultat);
                        mysql_close($connexio);
                ?>
                <div align="center"><form action="index.php"><input type="submit" value="Tornar"></form>
       </body>
</html>

