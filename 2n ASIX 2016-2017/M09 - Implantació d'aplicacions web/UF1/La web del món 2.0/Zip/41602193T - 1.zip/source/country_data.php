<html>
        <head>
<title>country_data.php</title>
</head>
        <body bgcolor="#A9CCE3">
                <?php
//Un cop hem obert la �part� php, el primer que tenim que fer es establir la connexi� amb l�usuari userbddworld, de la base de dades bdd_world.
                 $connexio=mysql_connect('localhost','userbddworld','asixmp09aea1031617');
                        if (!$connexio) {
                                die('No es pot connectar amb la base dades: ' .mysql_error());
                        }
//Tot seguit, fem lo mateix que el pas anterior, per� en aquest cas es si s�ha connectat amb la base de dades bdd_world, i en cas negatiu mostraria un missatge d�error.
                        if (!mysql_select_db('bdd_world')){
                                die('No es pot connectar amb la base de dades : ' .mysql_error());
                        }
//Mitjan�ant el m�tode GET mostrar� el assignem el codi del pa�s a codi.
                        if(isset($_GET['pais'])){
                                $codi=$_GET['pais'];
//Guardem el resultat de la consulta SQL a la variable $resultat.
                                $resultat=mysql_query("SELECT City.Name, City.ID, Country.Name, Country.Continent, Country.Population, Country.Capital, Country.GNP, Country.HeadOfState FROM City JOIN Country ON (City.CountryCode=Country.Code) WHERE Country.Code='$codi'");
//Assignem el contingut de la variable $resultat a la variable $row.
                                $row = mysql_fetch_array($resultat);
//Mostrarem mitjan�ant un echo els resultats de les consultes.
                                echo "<h1>$row[2]</h1>";
                                echo "<br></br>";
                                echo "<h2>CAPITAL</h2>";
                                echo "<h3>$row[0]</h3>";
                                echo "<br></br>";
                                echo "<h2>ID</h2>";
                                echo "<h3>$row[1]</h3>";
                                echo "<br></br>";
                                echo "<h2>CAPITAL</h2>";
                                echo "<h3>$row[5]</h3>";
                                echo "<br></br>";
                                echo "<h2>GNP</h2>";
                                echo "<h3>$row[6]</h3>";
                                echo "<br></br>";
                                echo "<h2>CAP D'ESTAT</h2>";
                                echo "<h3>$row[7]</h3>";
                                echo "<br></br>";
                                echo "<h2>CONTINENT</h2>";
                                echo "<h3>$row[3]</h3>";
                                echo "<br></br>";
                                echo "<h2>NOMBRE D'HABITANTS</h2>";
                                echo "<h3>$row[4]</h3>";
                                echo "<br></br>";
                                echo "<h2>CIUTATS I CAPITAL</h2>";
                                $cont=0;
                                do {
                                        $tab = 70-(strlen($row[0]))*2;
                                        if($row[1]==$row[5]){
                                                echo "<a href = city_data.php?ciutat=$row[1]><FONT FACE='Courier, Lucida Console, Consolas'>$row[0](CAPITAL)</FONT></a>".str_repeat('&nbsp', $tab-18);
                                        } else {
                                                echo "<a href = city_data.php?ciutat=$row[1]><FONT FACE='Courier, Lucida Console, Consolas'>$row[0] </FONT></a>".str_repeat('&nbsp', $tab);
                                        }
                                        if($cont==2){
                                                echo "</br>";
                                                $cont=0;
                                        } else {
                                                $cont=$cont+1;
                                        }
                                } while ($row = mysql_fetch_array($resultat));
                        }
                   	echo "<br></br>";
//Una vegada, hem mostrat tot el que vol�em, tanquem la connexi�
                        mysql_close($connexio);
                ?>
                <div align="center"><form action="index.php"><input type="submit" value="Tornar"></form>
        </body>
</html>
