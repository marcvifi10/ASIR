<html>
        <head>
<title>cities_list.php</title>
</head>
        <body bgcolor="#A9CCE3">
                <?php
 //Un cop hem obert la �part� php, el primer que tenim que fer es establir la connexi� amb l�usuari userbddworld, de la base de dades bdd_world.
                $connexio=mysql_connect('localhost','userbddworld','asixmp09aea1031617');
                        if (!$connexio) {
                                die('No es pot connectar amb la base dades: ' .mysql_error());
                        }
//Tot seguit, fem lo mateix que el pas anterior, per� en aquest cas es si s�ha connectat amb la base de dades bdd_world, i en cas negatiu mostraria un missatge d�error.
                        if (!mysql_select_db('bdd_world')){
                                die('No es pot connectar amb la base de dades : ' .mysql_error());
                        }
//En aquest part del codi, el que fa �s mirar si el nom que entrem per teclat coincideix amb el nom d�una ciutat de la nostra base de dades, mitjan�ant el m�tode GET.
                        if(isset($_GET['Find'])){
                                $nom=$_GET['Find'];
//Guardem el resultat de la consulta SQL a la variable resultat.
$resultat=mysql_query("SELECT City.Name, Country.Name, City.ID, Country.Continent FROM City City JOIN Country Country ON (City.CountryCode=Country.Code) WHERE City.Name LIKE '%$nom%' ");
//Posteriorment, guardem el contingut de la variable $resultat a la variable $row.
                                $row = mysql_fetch_array($resultat);
//Mostrarem mitjan�ant un echo els resultats de les consultes.
                                echo "<h1>$row[0]</h1>";
                                echo "<a href = city_data.php?ciutat=$row[0]><FONT FACE='Courier, Lucida Console, Consolas'>$row[0](Console, Consolas'>$row[1](CAPITAL)</FONT></a>";
        echo "<br></br>";
                                echo "<h2>PAIS</h2>";
                                echo "<h3>$row[1]</h3>";
                                echo "<br></br>";
                                echo "<h2>CONTINENT</h2>";
                                echo "<h3>$row[3]</h3>";
                         }
//Fem un salt de l�nia, mitjan�ant <br></br>.
                        echo "<br></br>";
//Una vegada ja hem mostrat tot el que vol�em tanquem la connexi�, i tanquem el document php.
mysql_close($connexio);
                ?>
                <div align="center"><form action="index.php"><input type="submit" value="Tornar"></form>
        </body>
</html>
