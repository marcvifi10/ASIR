<html>
        <head>
                <title>city_data.php</title>
        </head>
        <body bgcolor="#F5B7B1">
                <?php
 //Un cop hem obert la �part� php, el primer que tenim que fer es establir la connexi� amb l�usuari userbddworld, de la base de dades bdd_world.
                 $connexio=mysql_connect('localhost','userbddworld','asixmp09aea1031617');
                        if (!$connexio) {
                                die('No es pot connectar : ' .mysql_error());
                        }
//Tot seguit, fem lo mateix que el pas anterior, per� en aquest cas es si s�ha connectat amb la base de dades bdd_world, i en cas negatiu mostraria un missatge d�error.
                        if (!mysql_select_db('bdd_world')){
                                die('No es pot connectar amb la base de dades : ' .mysql_error());
                        }
//Mitjan�ant el m�tode GET, buscar� a la base de dades les ciutats que coincideixin amb el nom que nosaltres li entrem.
                        if(isset($_GET['ciutat']))
                        {
//Creem una variable anomenada codi, perqu� quan realitzem la consulta busqui els resultats que coincideixin.	                
                                $codi=$_GET['ciutat'];
//Guardem el resultat de la consulta SQL a la variable resultat.
                                $resultat=mysql_query("SELECT City.Name, City.District, Country.Name, Country.Continent, City.Population FROM City JOIN  Country ON (City.CountryCode=Country.Code) WHERE City.ID=$codi");
//Posteriorment, guardem el contingut de la variable $resultat a la variable $row.
                                $row = mysql_fetch_array($resultat);
//Mostrarem mitjan�ant un echo els resultats de les consultes.
                                echo "<h1>$row[0]</h1>";
                                echo "<br></br>";
                                echo "<h2>DISTRICTE</h2>";
                                echo "<h3>$row[1]</h3>";
                                echo "<br></br>";
                                echo "<h2>PAIS</h2>";
                                echo "<h3>$row[2]</h3>";
                                echo "<br></br>";
                                echo "<h2>CONTINENT</h2>";
                                echo "<h3>$row[3]</h3>";
                                echo "<br></br>";
                                echo "<h2>NOMBRE D'HABITANTS</h2>";
                                echo "<h3>$row[4]</h3>";
                                echo "<br></br>";
                        }
//Una vegada ja hem mostrat tot el que vol�em tanquem la connexi�, i tanquem el document php.
                        mysql_close($connexio);
                ?>
                <div align="center"><form action="index.php"><input type="submit" value="Tornar"></form>
        </body>
</html>
