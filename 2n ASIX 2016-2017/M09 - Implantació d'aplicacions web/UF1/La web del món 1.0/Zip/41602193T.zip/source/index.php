<html>
        <head>
                <title>index.php</title>
                <div align="center" style="color:red;"><h1>CITIES AND COUNTRIES OF THE WORLD</h1></div>
        </head>
        <body bgcolor="#A6ACAF">
                <table align="center" style="width:30%" border="3" >
                        <tr>
                                <td>
                                        <form  action="cities_list.php" method="GET">
                                                <p>CITIES:</br>
                                                <input type="text" name="Find">
                                                <input type="submit" value="Find"></br></p>
                                        </form>
                                </td>
                        </tr>
                </table>
                </br>
                <p align="center">COUNTRIES:</p>
                <table style border="3" align="center">
                        <tr>
                                <td>
                                        <div style=" width: 250px; height: 150px; overflow-y: scroll;">
                                                <?php
//Un cop hem obert la �part� php, el primer que tenim que fer es establir la connexi� amb l�usuari userbddworld, de la base de dades bdd_world.
                                                        $connexio = mysql_connect('localhost','userbddworld','asixmp09aea1031617');
//Una vegada fet el pas anterior, fem que si no s�estableix la connexi�, mostri un missatge d�error.
if (!$connexio){
                                                                die('No es pot connectar: ' .mysql_error());
                                                        }
//Tot seguit, fem lo mateix que el pas anterior, per� en aquest cas es si s�ha connectat amb la base de dades bdd_world, i en cas negatiu mostraria un missatge d�error.
                                                        if (!mysql_select_db('bdd_world')){
                                                                die ('No es pot connectar amb la seva base de dades: ' .mysql_error());
                                                        }
//Creem una variable anomenada $resultat, on hi guardem el resultat d�una consulta SQL gr�cies a mysql_query, i si no tenim permisos per fer la consulta, ens mostrar� un missatge d�error.
                                                        $resultat = mysql_query("SELECT Name, Code FROM Country ORDER BY Name ASC");
                                                        if (!$resultat){
                                                                die ('No t� la capacitat de consultar: ' .mysql_error());
                                                        }
//Llavors mitjan�ant mysql_fetch_array, li assignem a la variable row els valors que tenia resultat.
                                                        while ($row = mysql_fetch_array($resultat)){
//Tot seguit, mitjan�ant un echo mostrar� els noms del pa�sos, ja que row[0], fa referencia a la primera variable que  consultem (SELECT Name, Code FROM Country ORDER BY Name ASC).
                                                                echo "<a href = country_data.php?pais=$row[1]>$row[0]</br></a>";
                                                        }
?>
                                        </div>
                                </td>
                        </tr>
                </table>
	<br></br>
                <div align="center">

                                <form method="GET" action="top_cities.php" style="display:inline";>
                                <input type="submit" value="Top Cities">
                        </form>
<form  method="GET" action="top_countries.php" style="display:inline";>
                                <input type="submit" value="Top Countries">
                        </form>
                </div>
        </body>
</html>
