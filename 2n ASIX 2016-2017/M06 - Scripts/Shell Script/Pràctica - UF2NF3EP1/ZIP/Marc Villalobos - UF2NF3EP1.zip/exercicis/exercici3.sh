#!/bin/bash
#exercici3.sh
clear
echo "Quina interfície de xarxa vols configurar?"
echo $1
echo "Quina adreça ip vols posar?"
echo $2
echo "Quina màscara li vols posar?"
echo $3
echo "Quin gateway li vols posar?"
echo $4

ifconfig $1 $2 netmask $3 broadcast $4
