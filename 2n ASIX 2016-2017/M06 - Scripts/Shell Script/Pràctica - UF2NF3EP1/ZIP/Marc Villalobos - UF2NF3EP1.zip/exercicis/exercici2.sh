#!/bin/bash
#exercici2.sh

clear
echo "
SELECCIONA UNA OPCIÓ:
A. Crear un usuari
B. Crear un grup
C. Assignar un usuari a un grup
D. Modificar un usuari
E. Llistar usuaris d'un grup
Q. Surt
"
read -p "SELECCIONA UNA OPCIÓ [A, B, C, D, E o Q]>"
case $REPLY in
   q|Q) echo "Programa acabat."
      exit
      ;;
   a|A) echo "Crear un usuari: "
     	echo "Entra el nom de l'usuari que vols crear: "
	read NOM_USUARI
	useradd $NOM_USUARI
	;;
   b|B) echo "Crear un grup: "
	echo "Entra el nom del grup que vols crear: "
	read NOM_GROUP
	addgroup $NOM_GROUP
	;;
   c|C) echo "Assignar un usuari a un grup: "
	echo "Entra el nom de l'usuari i del grup que el vulguis afegir: "
	read NOM_USUARI
		if id -u "$NOM_USUARI" >/dev/null 2>&1; then
			echo "L'usuari existeix"
		else
			echo "L'usuari no existeix!!!"
		fi
	echo "Entra el nom del grup on el vulguis afegir: "
	read NOM_GRUP
		 if id -u "$NOM_GRUP" >/dev/null 2>&1; then
                        echo "El grup existeix"
                else
                        echo "El grup no existeix!!!"
                fi
	adduser $NOM_USUARI $NOM_GRUP
	;;
   d|D) echo "Modificar un usuari: "
	echo "Entra el nom de l'usuari que vulguis modificar: "
	read NOM_USUARI
	passwd $NOM_USUARI
	;;
   e|E) echo "Llistar els usuaris d'un grup: "
	echo "Entra el nom d'un grup qualsevol: "
	read NOM_GRUP
	grep $NOM_GRUP /etc/group
	;;
   *) echo "Caràcter invàlid"  >&2
   exit i
   ;;
esac
