#!/bin/bash

#exercici1.sh


if [ -f $1 ]; then
	
echo "Obtinguent els usuaris de l'arxiu"

fi


for i in $(cat usuaris.csv); 
do
	
nom=`echo $i|cut -d ";" -f1`
	
password=`echo $i|cut -d ";" -f2`
	
directori=`echo $i|cut -d ";" -f3`

	
useradd -d $directori -m $nom

	
echo $nom:$password:$directori


done
