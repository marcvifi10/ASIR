#!/bin/bash
#contarparaules
clear

echo "QUANTES VEGADES HI ÉS LA PARAULA APACHE?"
echo "La paraula apache apareix"
grep -c "apache" paraules.txt 
echo "vegades"
echo "QUANTES VEGADES HI ÉS LA PARAULA CRON?"
echo "La paraula cron apareix"
grep -c "cron" paraules.txt
echo "vegades"
echo "QUANTES VEGADES HI ÉS LA PARAULA SYSLOG?"
echo "La paraula syslog apareix"
grep -c "syslog" paraules.txt
echo "vegades"
echo "QUANTES VEGADES HI ÉS LA PARAULA CRITICAL?"
echo "La paraula critical apareix"
grep -c "critical" paraules.txt
echo "vegades"

